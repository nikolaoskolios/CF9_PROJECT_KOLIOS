"""Upload a new test result using a saved API token.

Reads the API key from api_token.json (next to this script, generated via
POST /auth/api-key) and POSTs a JSON test record to POST /test-results/.

Usage:
    python upload_test_data.py [path/to/test_result.json]

If no JSON path is given, sample_test_result.json (next to this script) is
used.
"""
import json
import sys
from pathlib import Path

import httpx

API_BASE_URL = "http://localhost:8000"
SCRIPT_DIR = Path(__file__).resolve().parent
API_KEY_FILE = SCRIPT_DIR / "api_token.json"
DEFAULT_JSON_FILE = SCRIPT_DIR / "test_result.json"


def main() -> None:
    api_key = json.loads(API_KEY_FILE.read_text())["api_key"]
    json_path = Path(sys.argv[1]) if len(sys.argv) > 1 else DEFAULT_JSON_FILE
    payload = json.loads(json_path.read_text())

    response = httpx.post(
        f"{API_BASE_URL}/test-results/",
        json=payload,
        headers={"X-API-Key": api_key},
    )

    if response.status_code == 201:
        print(f"Uploaded build {payload.get('build')!r} successfully.")
    else:
        print(f"Upload failed ({response.status_code}): {response.text}")
        sys.exit(1)


if __name__ == "__main__":
    main()
